% case 2. homogeneous space - semi-infinite PC waveguide

%% Field visualization

%LFMM_Bmode_field_visual_xz_case2_Lfree_Rwg_downup;
LFMM_Bmode_field_visual_xz_case2_Lfree_Rwg_updown;