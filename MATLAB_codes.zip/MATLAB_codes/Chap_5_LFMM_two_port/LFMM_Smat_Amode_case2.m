% case 2. homogeneous space - semi-infinite PC waveguide

%LFMM_Amode_field_visual_xz_case2_Lfree_Rwg_leftright;
LFMM_Amode_field_visual_xz_case2_Lfree_Rwg_rightleft;