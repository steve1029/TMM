% case 3. semi-infinite PC waveguide - homogeneous space

%% Field visualization

LFMM_Bmode_field_visual_xz_case3_Lwg_Rfree_downup;
%LFMM_Bmode_field_visual_xz_case3_Lwg_Rfree_updown;