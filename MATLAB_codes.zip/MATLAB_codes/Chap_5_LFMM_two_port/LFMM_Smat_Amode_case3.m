% case 3. semi-infinite PC waveguide - homogeneous space

%LFMM_Amode_field_visual_xz_case3_Lwg_Rfree_leftright;
LFMM_Amode_field_visual_xz_case3_Lwg_Rfree_rightleft;